import Vue from 'vue'
import VDistpicker from 'v-distpicker'

Vue.component('v-distpicker', VDistpicker);
