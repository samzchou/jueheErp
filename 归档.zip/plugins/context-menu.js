import Vue from 'vue'
import contextMenu from 'vue-context-menu'

Vue.component('context-menu', contextMenu)