import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _1446a90d = () => import('..\\pages\\invoice\\index.vue' /* webpackChunkName: "pages_invoice_index" */).then(m => m.default || m)
const _bf4a5a56 = () => import('..\\pages\\invoice\\index\\index.vue' /* webpackChunkName: "pages_invoice_index_index" */).then(m => m.default || m)
const _5248b06d = () => import('..\\pages\\invoice\\index\\collect.vue' /* webpackChunkName: "pages_invoice_index_collect" */).then(m => m.default || m)
const _f48bcac0 = () => import('..\\pages\\invoice\\index\\finish.vue' /* webpackChunkName: "pages_invoice_index_finish" */).then(m => m.default || m)
const _1667495e = () => import('..\\pages\\login\\index.vue' /* webpackChunkName: "pages_login_index" */).then(m => m.default || m)
const _13e63c36 = () => import('..\\pages\\order\\plane-list.vue' /* webpackChunkName: "pages_order_plane-list" */).then(m => m.default || m)
const _477ccd54 = () => import('..\\pages\\order\\import-buy.vue' /* webpackChunkName: "pages_order_import-buy" */).then(m => m.default || m)
const _703a97c6 = () => import('..\\pages\\store\\outsend.vue' /* webpackChunkName: "pages_store_outsend" */).then(m => m.default || m)
const _45d77e8c = () => import('..\\pages\\finial\\invoice.vue' /* webpackChunkName: "pages_finial_invoice" */).then(m => m.default || m)
const _34e9fcc6 = () => import('..\\pages\\store\\calc-list.vue' /* webpackChunkName: "pages_store_calc-list" */).then(m => m.default || m)
const _ba77d000 = () => import('..\\pages\\options\\type.vue' /* webpackChunkName: "pages_options_type" */).then(m => m.default || m)
const _58cb8ee9 = () => import('..\\pages\\order\\import-sale.vue' /* webpackChunkName: "pages_order_import-sale" */).then(m => m.default || m)
const _683df0a8 = () => import('..\\pages\\options\\payType.vue' /* webpackChunkName: "pages_options_payType" */).then(m => m.default || m)
const _e0bf8300 = () => import('..\\pages\\order\\buy.vue' /* webpackChunkName: "pages_order_buy" */).then(m => m.default || m)
const _9b7613a8 = () => import('..\\pages\\options\\storeNo.vue' /* webpackChunkName: "pages_options_storeNo" */).then(m => m.default || m)
const _63d52e8e = () => import('..\\pages\\options\\org.vue' /* webpackChunkName: "pages_options_org" */).then(m => m.default || m)
const _4f0b07d4 = () => import('..\\pages\\options\\ptype.vue' /* webpackChunkName: "pages_options_ptype" */).then(m => m.default || m)
const _308422ad = () => import('..\\pages\\options\\flowState.vue' /* webpackChunkName: "pages_options_flowState" */).then(m => m.default || m)
const _653a6117 = () => import('..\\pages\\finial\\payout.vue' /* webpackChunkName: "pages_finial_payout" */).then(m => m.default || m)
const _1c46d832 = () => import('..\\pages\\produce\\on.vue' /* webpackChunkName: "pages_produce_on" */).then(m => m.default || m)
const _65f575de = () => import('..\\pages\\order\\sale-list.vue' /* webpackChunkName: "pages_order_sale-list" */).then(m => m.default || m)
const _40817628 = () => import('..\\pages\\finial\\payin.vue' /* webpackChunkName: "pages_finial_payin" */).then(m => m.default || m)
const _0587af9a = () => import('..\\pages\\order\\pake-list.vue' /* webpackChunkName: "pages_order_pake-list" */).then(m => m.default || m)
const _79f2ca56 = () => import('..\\pages\\order\\order-row.vue' /* webpackChunkName: "pages_order_order-row" */).then(m => m.default || m)
const _b2d5c894 = () => import('..\\pages\\store\\in-sale.vue' /* webpackChunkName: "pages_store_in-sale" */).then(m => m.default || m)
const _200c6f15 = () => import('..\\pages\\store\\out.vue' /* webpackChunkName: "pages_store_out" */).then(m => m.default || m)
const _650c4b98 = () => import('..\\pages\\meta\\user.vue' /* webpackChunkName: "pages_meta_user" */).then(m => m.default || m)
const _1516433d = () => import('..\\pages\\order\\sale.vue' /* webpackChunkName: "pages_order_sale" */).then(m => m.default || m)
const _647b609f = () => import('..\\pages\\order\\deliver.vue' /* webpackChunkName: "pages_order_deliver" */).then(m => m.default || m)
const _1f947f2e = () => import('..\\pages\\store\\in.vue' /* webpackChunkName: "pages_store_in" */).then(m => m.default || m)
const _4696259c = () => import('..\\pages\\meta\\product.vue' /* webpackChunkName: "pages_meta_product" */).then(m => m.default || m)
const _53cbc7c4 = () => import('..\\pages\\store\\calc.vue' /* webpackChunkName: "pages_store_calc" */).then(m => m.default || m)
const _899fe988 = () => import('..\\pages\\options\\role.vue' /* webpackChunkName: "pages_options_role" */).then(m => m.default || m)
const _a5d01a32 = () => import('..\\pages\\store\\in-buy.vue' /* webpackChunkName: "pages_store_in-buy" */).then(m => m.default || m)
const _0fe1e021 = () => import('..\\pages\\meta\\crm.vue' /* webpackChunkName: "pages_meta_crm" */).then(m => m.default || m)
const _4875e70a = () => import('..\\pages\\order\\buy-list.vue' /* webpackChunkName: "pages_order_buy-list" */).then(m => m.default || m)
const _d7740c04 = () => import('..\\pages\\options\\pos.vue' /* webpackChunkName: "pages_options_pos" */).then(m => m.default || m)
const _1747d0fa = () => import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */).then(m => m.default || m)



if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/invoice",
			component: _1446a90d,
			children: [
				{
					path: "",
					component: _bf4a5a56,
					name: "invoice-index"
				},
				{
					path: "collect",
					component: _5248b06d,
					name: "invoice-index-collect"
				},
				{
					path: "finish",
					component: _f48bcac0,
					name: "invoice-index-finish"
				}
			]
		},
		{
			path: "/login",
			component: _1667495e,
			name: "login"
		},
		{
			path: "/order/plane-list",
			component: _13e63c36,
			name: "order-plane-list"
		},
		{
			path: "/order/import-buy",
			component: _477ccd54,
			name: "order-import-buy"
		},
		{
			path: "/store/outsend",
			component: _703a97c6,
			name: "store-outsend"
		},
		{
			path: "/finial/invoice",
			component: _45d77e8c,
			name: "finial-invoice"
		},
		{
			path: "/store/calc-list",
			component: _34e9fcc6,
			name: "store-calc-list"
		},
		{
			path: "/options/type",
			component: _ba77d000,
			name: "options-type"
		},
		{
			path: "/order/import-sale",
			component: _58cb8ee9,
			name: "order-import-sale"
		},
		{
			path: "/options/payType",
			component: _683df0a8,
			name: "options-payType"
		},
		{
			path: "/order/buy",
			component: _e0bf8300,
			name: "order-buy"
		},
		{
			path: "/options/storeNo",
			component: _9b7613a8,
			name: "options-storeNo"
		},
		{
			path: "/options/org",
			component: _63d52e8e,
			name: "options-org"
		},
		{
			path: "/options/ptype",
			component: _4f0b07d4,
			name: "options-ptype"
		},
		{
			path: "/options/flowState",
			component: _308422ad,
			name: "options-flowState"
		},
		{
			path: "/finial/payout",
			component: _653a6117,
			name: "finial-payout"
		},
		{
			path: "/produce/on",
			component: _1c46d832,
			name: "produce-on"
		},
		{
			path: "/order/sale-list",
			component: _65f575de,
			name: "order-sale-list"
		},
		{
			path: "/finial/payin",
			component: _40817628,
			name: "finial-payin"
		},
		{
			path: "/order/pake-list",
			component: _0587af9a,
			name: "order-pake-list"
		},
		{
			path: "/order/order-row",
			component: _79f2ca56,
			name: "order-order-row"
		},
		{
			path: "/store/in-sale",
			component: _b2d5c894,
			name: "store-in-sale"
		},
		{
			path: "/store/out",
			component: _200c6f15,
			name: "store-out"
		},
		{
			path: "/meta/user",
			component: _650c4b98,
			name: "meta-user"
		},
		{
			path: "/order/sale",
			component: _1516433d,
			name: "order-sale"
		},
		{
			path: "/order/deliver",
			component: _647b609f,
			name: "order-deliver"
		},
		{
			path: "/store/in",
			component: _1f947f2e,
			name: "store-in"
		},
		{
			path: "/meta/product",
			component: _4696259c,
			name: "meta-product"
		},
		{
			path: "/store/calc",
			component: _53cbc7c4,
			name: "store-calc"
		},
		{
			path: "/options/role",
			component: _899fe988,
			name: "options-role"
		},
		{
			path: "/store/in-buy",
			component: _a5d01a32,
			name: "store-in-buy"
		},
		{
			path: "/meta/crm",
			component: _0fe1e021,
			name: "meta-crm"
		},
		{
			path: "/order/buy-list",
			component: _4875e70a,
			name: "order-buy-list"
		},
		{
			path: "/options/pos",
			component: _d7740c04,
			name: "options-pos"
		},
		{
			path: "/",
			component: _1747d0fa,
			name: "index"
		}
    ],
    
    
    fallback: false
  })
}
