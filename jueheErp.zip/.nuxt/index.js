import 'es6-promise/auto'
import Vue from 'vue'
import Meta from 'vue-meta'
import { createRouter } from './router.js'
import NoSSR from './components/no-ssr.js'
import NuxtChild from './components/nuxt-child.js'
import NuxtLink from './components/nuxt-link.js'
import NuxtError from './components/nuxt-error.vue'
import Nuxt from './components/nuxt.js'
import App from './App.js'
import { setContext, getLocation, getRouteData } from './utils'
import { createStore } from './store.js'

/* Plugins */
import nuxt_plugin_axios_a18b4f40 from 'nuxt_plugin_axios_a18b4f40' // Source: ./axios.js
import nuxt_plugin_polyfill_14930cc5 from 'nuxt_plugin_polyfill_14930cc5' // Source: ..\\plugins\\polyfill (ssr: false)
import nuxt_plugin_lodash_52e6a2ea from 'nuxt_plugin_lodash_52e6a2ea' // Source: ..\\plugins\\lodash
import nuxt_plugin_moment_4f74a614 from 'nuxt_plugin_moment_4f74a614' // Source: ..\\plugins\\moment
import nuxt_plugin_cookies_1f907659 from 'nuxt_plugin_cookies_1f907659' // Source: ..\\plugins\\cookies (ssr: false)
import nuxt_plugin_i18n_6a80ea94 from 'nuxt_plugin_i18n_6a80ea94' // Source: ..\\plugins\\i18n
import nuxt_plugin_elementui_a6a1b20a from 'nuxt_plugin_elementui_a6a1b20a' // Source: ..\\plugins\\element-ui
import nuxt_plugin_axios_3566aa80 from 'nuxt_plugin_axios_3566aa80' // Source: ..\\plugins\\axios
import nuxt_plugin_filters_2b4f519a from 'nuxt_plugin_filters_2b4f519a' // Source: ..\\plugins\\filters.js
import nuxt_plugin_global_f21f4e84 from 'nuxt_plugin_global_f21f4e84' // Source: ..\\plugins\\global.js
import nuxt_plugin_print_33c55e12 from 'nuxt_plugin_print_33c55e12' // Source: ..\\plugins\\print
import nuxt_plugin_storage_767f7645 from 'nuxt_plugin_storage_767f7645' // Source: ..\\plugins\\storage (ssr: false)
import nuxt_plugin_echarts_747bb8c4 from 'nuxt_plugin_echarts_747bb8c4' // Source: ..\\plugins\\echarts (ssr: false)
import nuxt_plugin_VDistpicker_3dda2d18 from 'nuxt_plugin_VDistpicker_3dda2d18' // Source: ..\\plugins\\VDistpicker (ssr: false)
import nuxt_plugin_contextmenu_bb8a5d9a from 'nuxt_plugin_contextmenu_bb8a5d9a' // Source: ..\\plugins\\context-menu (ssr: false)


// Component: <no-ssr>
Vue.component(NoSSR.name, NoSSR)

// Component: <nuxt-child>
Vue.component(NuxtChild.name, NuxtChild)

// Component: <nuxt-link>
Vue.component(NuxtLink.name, NuxtLink)

// Component: <nuxt>`
Vue.component(Nuxt.name, Nuxt)

// vue-meta configuration
Vue.use(Meta, {
  keyName: 'head', // the component option name that vue-meta looks for meta info on.
  attribute: 'data-n-head', // the attribute name vue-meta adds to the tags it observes
  ssrAttribute: 'data-n-head-ssr', // the attribute name that lets vue-meta know that meta info has already been server-rendered
  tagIDKeyName: 'hid' // the property name that vue-meta uses to determine whether to overwrite or append a tag
})

const defaultTransition = {"name":"page","mode":"out-in","appear":false,"appearClass":"appear","appearActiveClass":"appear-active","appearToClass":"appear-to"}

async function createApp (ssrContext) {
  const router = createRouter(ssrContext)

  
  const store = createStore(ssrContext)
  // Add this.$router into store actions/mutations
  store.$router = router
  

  // Create Root instance
  // here we inject the router and store to all child components,
  // making them available everywhere as `this.$router` and `this.$store`.
  const app = {
    router,
    store,
    nuxt: {
      defaultTransition,
      transitions: [ defaultTransition ],
      setTransitions (transitions) {
        if (!Array.isArray(transitions)) {
          transitions = [ transitions ]
        }
        transitions = transitions.map((transition) => {
          if (!transition) {
            transition = defaultTransition
          } else if (typeof transition === 'string') {
            transition = Object.assign({}, defaultTransition, { name: transition })
          } else {
            transition = Object.assign({}, defaultTransition, transition)
          }
          return transition
        })
        this.$options.nuxt.transitions = transitions
        return transitions
      },
      err: null,
      dateErr: null,
      error (err) {
        err = err || null
        app.context._errored = !!err
        if (typeof err === 'string') err = { statusCode: 500, message: err }
        const nuxt = this.nuxt || this.$options.nuxt
        nuxt.dateErr = Date.now()
        nuxt.err = err
        // Used in lib/server.js
        if (ssrContext) ssrContext.nuxt.error = err
        return err
      }
    },
    ...App
  }
  
  // Make app available into store via this.app
  store.app = app
  
  const next = ssrContext ? ssrContext.next : location => app.router.push(location)
  // Resolve route
  let route
  if (ssrContext) {
    route = router.resolve(ssrContext.url).route
  } else {
    const path = getLocation(router.options.base)
    route = router.resolve(path).route
  }

  // Set context to app.context
  await setContext(app, {
    route,
    next,
    error: app.nuxt.error.bind(app),
    store,
    payload: ssrContext ? ssrContext.payload : undefined,
    req: ssrContext ? ssrContext.req : undefined,
    res: ssrContext ? ssrContext.res : undefined,
    beforeRenderFns: ssrContext ? ssrContext.beforeRenderFns : undefined
  })

  const inject = function (key, value) {
    if (!key) throw new Error('inject(key, value) has no key provided')
    if (!value) throw new Error('inject(key, value) has no value provided')
    key = '$' + key
    // Add into app
    app[key] = value
    
    // Add into store
    store[key] = app[key]
    
    // Check if plugin not already installed
    const installKey = '__nuxt_' + key + '_installed__'
    if (Vue[installKey]) return
    Vue[installKey] = true
    // Call Vue.use() to install the plugin into vm
    Vue.use(() => {
      if (!Vue.prototype.hasOwnProperty(key)) {
        Object.defineProperty(Vue.prototype, key, {
          get () {
            return this.$root.$options[key]
          }
        })
      }
    })
  }

  
  if (process.browser) {
    // Replace store state before plugins execution
    if (window.__NUXT__ && window.__NUXT__.state) {
      store.replaceState(window.__NUXT__.state)
    }
  }
  

  // Plugin execution
  
  if (typeof nuxt_plugin_axios_a18b4f40 === 'function') await nuxt_plugin_axios_a18b4f40(app.context, inject)
  if (typeof nuxt_plugin_lodash_52e6a2ea === 'function') await nuxt_plugin_lodash_52e6a2ea(app.context, inject)
  if (typeof nuxt_plugin_moment_4f74a614 === 'function') await nuxt_plugin_moment_4f74a614(app.context, inject)
  if (typeof nuxt_plugin_i18n_6a80ea94 === 'function') await nuxt_plugin_i18n_6a80ea94(app.context, inject)
  if (typeof nuxt_plugin_elementui_a6a1b20a === 'function') await nuxt_plugin_elementui_a6a1b20a(app.context, inject)
  if (typeof nuxt_plugin_axios_3566aa80 === 'function') await nuxt_plugin_axios_3566aa80(app.context, inject)
  if (typeof nuxt_plugin_filters_2b4f519a === 'function') await nuxt_plugin_filters_2b4f519a(app.context, inject)
  if (typeof nuxt_plugin_global_f21f4e84 === 'function') await nuxt_plugin_global_f21f4e84(app.context, inject)
  if (typeof nuxt_plugin_print_33c55e12 === 'function') await nuxt_plugin_print_33c55e12(app.context, inject)
  
  if (process.browser) { 
    if (typeof nuxt_plugin_polyfill_14930cc5 === 'function') await nuxt_plugin_polyfill_14930cc5(app.context, inject)
    if (typeof nuxt_plugin_cookies_1f907659 === 'function') await nuxt_plugin_cookies_1f907659(app.context, inject)
    if (typeof nuxt_plugin_storage_767f7645 === 'function') await nuxt_plugin_storage_767f7645(app.context, inject)
    if (typeof nuxt_plugin_echarts_747bb8c4 === 'function') await nuxt_plugin_echarts_747bb8c4(app.context, inject)
    if (typeof nuxt_plugin_VDistpicker_3dda2d18 === 'function') await nuxt_plugin_VDistpicker_3dda2d18(app.context, inject)
    if (typeof nuxt_plugin_contextmenu_bb8a5d9a === 'function') await nuxt_plugin_contextmenu_bb8a5d9a(app.context, inject)
  }

  // If server-side, wait for async component to be resolved first
  if (process.server && ssrContext && ssrContext.url) {
    await new Promise((resolve, reject) => {
      router.push(ssrContext.url, resolve, () => {
        // navigated to a different route in router guard
        const unregister = router.afterEach(async (to, from, next) => {
          ssrContext.url = to.fullPath
          app.context.route = await getRouteData(to)
          app.context.params = to.params || {}
          app.context.query = to.query || {}
          unregister()
          resolve()
        })
      })
    })
  }

  return {
    app,
    router,
    store
  }
}

export { createApp, NuxtError }
