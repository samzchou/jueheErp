import Vue from 'vue'
import VueCookies from 'vue-cookies'

export default ({ app, store }) => {
  Vue.use(VueCookies)
}
