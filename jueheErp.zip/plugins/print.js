import Vue from 'vue';
//import Print from '@/util/print' // 引入附件的js文件
import Print from 'vue-print-nb';
Vue.use(Print) 